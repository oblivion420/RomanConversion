bulletin = [
    {
        "date": "Lastest",
        "items": [
            "編輯熱鍵操作： 更新熱鍵設定為alt+play(P), alt+update(U)",
        ]
    },
]
