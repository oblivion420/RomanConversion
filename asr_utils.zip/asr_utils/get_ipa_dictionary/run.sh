#!/bin/bash

# taigiE
echo "TaigiE..."
python3 main.py --taigi --english

# taigi
# echo "Taigi..."
# python3 main.py --taigi

# mandarinE
# echo "MandarinE..."
# python3 main.py --mandarin --english
