mandarin_DB = {
    "server_name": "140.109.23.160",
    "port": 3307,
    "db_name": "Mandarin",
    "table_all_dictionary": "standard_dictionary",
    "username": "admin",
    "password": "sinicaslamadmin",
}

taigi_DB = {
    "server_name": "140.109.23.160",
    "port": 3307,
    "db_name": "Taigi",
    "table_all_dictionary": "standard_dictionary",
    "table_phrase_dictionary": "phrase_dictionary",
    "table_drama": "drama",
    "table_drama_transcript": "drama_transcript",
    "username": "admin",
    "password": "sinicaslamadmin",
}
